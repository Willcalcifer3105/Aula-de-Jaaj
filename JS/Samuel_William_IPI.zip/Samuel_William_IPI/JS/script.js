function Atividade1() {
    var alertShown = false;
    window.addEventListener('scroll', function() {
        if (!alertShown) {
            var elemento = document.getElementById('001');
            if (elemento) {
                var rect = elemento.getBoundingClientRect();
                var windowHeight = window.innerHeight || document.documentElement.clientHeight;
                var elementHeight = elemento.offsetHeight;
                var percentVisible = ((windowHeight - rect.top) / elementHeight) * 100;

                // Verifica se o elemento está 85% visível
                if (percentVisible >= 85) {
                    alert('Este é o Alerta da atividade 1');
                    alertShown = true;
                }
            }
        }
    });
}

Atividade1();

function Atividade2(){
        alert('Você pressionou o botão!');
}

function Atividade3_1() {

    const boxes = document.getElementsByClassName('texto');

    for (let i = 0; i < boxes.length; i++) {
        boxes[i].classList.add('marcatexto');
    }
}

function Atividade3_2() {
    const paragraphs = document.getElementsByTagName('p');
    for (let i = 0; i < paragraphs.length; i++) {
        paragraphs[i].textContent = "Novo texto para o parágrafo " + (i + 1);
    }
}

function Atividade3_3() {
    const listItems = document.querySelectorAll('ul li');
    listItems.forEach(item => {
        item.classList.add('negro');
    });
}

function Atividade4_1() {
    document.getElementById('passaramao').style.backgroundColor = 'blue';
}

function Atividade4_2() {
    document.getElementById('mInput').style.border = '2px solid red';
}

function Atividade4_3() {
    const selectedValue = document.getElementById('selecao').value;
    document.getElementById('idselecao').innerText = "Opção selecionada: " + selectedValue;
}

function Atividade5_1() {
   alert("oi meninão");
}

function Atividade5_2() {
    alert("Eae Professor, da um MB ai pa nois (eu sei que ta escrito errado)");
};

function Atividade6() {
    var htmlcont = document.getElementById('cont');
    var jscont = parseInt(htmlcont.innerText);
    jscont++;
    htmlcont.innerText = jscont;
}



function Atividade7(){
	let valor = document.getElementById("fname").value;

	const paragraph = document.getElementById('palavra');
    paragraph.textContent = valor.toUpperCase();
}

function Atividade8_1(){
	let numb1 = document.getElementById("numb1").value;
	let numb2 = document.getElementById("numb2").value;
	let nc1 = parseInt(numb1)
	let nc2 = parseInt(numb2)

	let soma = nc1 + nc2;

	const resultado = document.getElementById('resultado');
    resultado.textContent = "O Resultado da soma é: " + soma;
}

function Atividade8_2(){
	let numb1 = document.getElementById("numb1").value;
	let numb2 = document.getElementById("numb2").value;
	let nc1 = parseInt(numb1)
	let nc2 = parseInt(numb2)

	let sub = nc1 - nc2;

	const resultado = document.getElementById('resultado');
    resultado.textContent = "O Resultado da subtração é: " + sub;
}

function Atividade8_3(){
	let numb1 = document.getElementById("numb1").value;
	let numb2 = document.getElementById("numb2").value;
	let nc1 = parseInt(numb1)
	let nc2 = parseInt(numb2)

	let mult = nc1 * nc2;

	const resultado = document.getElementById('resultado');
    resultado.textContent = "O Resultado da multiplicação é: " + mult;
}

function Atividade8_4(){
	let numb1 = document.getElementById("numb1").value;
	let numb2 = document.getElementById("numb2").value;
	let nc1 = parseInt(numb1)
	let nc2 = parseInt(numb2)

	let divi = nc1 / nc2;

	const resultado = document.getElementById('resultado');
    resultado.textContent = "O Resultado da divisão é: " + divi;
}
